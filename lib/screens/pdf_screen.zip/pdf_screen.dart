
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sales_quote_arnexa/screens/login_screen.dart';
import 'package:sales_quote_arnexa/services/auth_service.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:sales_quote_arnexa/models/price_model.dart';

Future<void> generatePdf() async {
  final pdf = pw.Document();
  
  final logo = await imageFromAssetBundle('assets/images/logo.png');

  
  pdf.addPage(
    pw.Page(
      margin: const pw.EdgeInsets.all(10),
      build: (context) {
        return pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [

            /// 🔴 HEADER
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(8),
                decoration: pw.BoxDecoration(
                color: PdfColors.yellow, // 👈 background color
                border: pw.Border.all(color: PdfColors.grey),
              ),
              child: pw.Column(
                children: [
                  pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text("MARUTI SUZUKI ARENA"),
                      pw.Image(logo, width: 80),
                    ],
                  ),
                  pw.SizedBox(height: 5),
                  pw.Text(
                    "PREM MOTORS PVT. LTD.",
                    style: pw.TextStyle(
                      color: PdfColor(1, 0, 0),
                      fontSize: 18,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                  pw.Text("(Authorised Maruti Suzuki Dealer)"),
                  pw.Text("Location Address : Jaipur"),
                  pw.Text("City: Jaipur | Pincode: 302006"),
                  pw.Text("Contact: 8929268096"),
                  pw.Text("Website: www.premmotors.com",
                      style: pw.TextStyle(color: PdfColors.blue)),
                ],
              ),
            ),

            pw.SizedBox(height: 5),

            /// 🟢 CUSTOMER
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey),
              children: [
                row("Customer Name", "HARISH", "Date", "16-05-2025"),
                row("Contact", "8949682733", "Email", ""),
                row("City", "Delhi", "Profession", "Farmer"),
                row("Corporate Name", " (ABC NONE Corporate)", "SRM (M.)", "Farmer"),
              ],
            ),

            /// 🟡 RM / SRM
            pw.Container(
              color: PdfColors.yellow,
              padding: const pw.EdgeInsets.all(5),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text("RM: Prakash"),
                  pw.Text("SRM: Anil"),
                ],
              ),
            ),

            pw.SizedBox(height: 5),

            /// TITLE
            pw.Center(
              child: pw.Text("PERFORMA INVOICE",
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            ),

            pw.Divider(),

            /// 🚗 VEHICLE
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey),
              children: [
                row("Model", "ALTO", "Variant", "LXI"),
                row("Color", "White", "Type", "Cash"),
              ],
            ),

            pw.SizedBox(height: 5),

            /// 💰 PRICE TITLE
            // titleBar("PRICE BREAK-UP"),
             pw.Center(
              child: pw.Text("PRICE BREAK-UP",
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            ),

            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey),
              columnWidths: {
                0: const pw.FlexColumnWidth(3),
                1: const pw.FlexColumnWidth(1),
              },
              children: [

                priceRow("Ex-Showroom", "583500"),
                priceRow("Insurance", "20926"),
                priceRow("RTO", "63130"),

                /// 🟡 WITHOUT OFFERS
                pw.TableRow(
                  decoration: const pw.BoxDecoration(color: PdfColors.yellow),
                  children: [
                    cell("On Road Price Without Offers", bold: true),
                    cell("Rs. 695672", alignRight: true, bold: true),
                  ],
                  
                ),

                priceRow("Corporate Offer", "0"),
                priceRow("Consumer Offer", "10000"),
                priceRow("Exchange Offer", "15000"),
                priceRow("Addnl. Discount", "0"),

                /// 🟡 FINAL
                pw.TableRow(
                  decoration: const pw.BoxDecoration(color: PdfColors.yellow),
                  children: [
                    cell("On Road Price After Applicable Offers", bold: true),
                    cell("Rs. 670672", alignRight: true, bold: true),
                  ],
                ),
              ],
            ),

            pw.SizedBox(height: 5),

            /// 🔵 EMI
            titleBar("EMI Details"),

            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey),
              children: [
                row("Finance On", "Cash", "Loan Amount", "0"),
                row("ROI", "0.00 %", "Tenure", "0"),
                row("EMI Amount", "0", "*ROI Will Subject to change as per CIBIL score", ""),
              ],
            ),

          
            pw.SizedBox(height: 5),

            /// 📄 TERMS
            titleBar("Terms and Conditions"),

            pw.Text("1. All Products are as per company policy."),
            pw.Text("2. Delivery subject to availability."),
            pw.Text("3. Price applicable at invoicing."),
            pw.Text("4. Delivery after full payment."),
            pw.Text("5. Jurisdiction applicable."),

            pw.SizedBox(height: 5),

            /// 🏦 BANK
            bankRow("Bank Name", "HDFC BANK LTD."),
            bankRow("Beneficiary", "PREM MOTORS PVT LTD"),
            bankRow("Account Number", "50200029378770"),
            bankRow("IFSC Code", "HDFC0001585"),
            bankRow("Branch Name", "Jaipur"),

            
            
          ],
        );
      },
    ),
  );

  await Printing.layoutPdf(onLayout: (format) async => pdf.save());
}


/// 🔹 TABLE ROW
pw.TableRow row(String l1, String v1, String l2, String v2) {
  return pw.TableRow(children: [
    cell("$l1: $v1"),
    cell("$l2: $v2"),
  ]);
}

/// 🔹 PRICE ROW
pw.TableRow priceRow(String label, String value) {
  return pw.TableRow(children: [
    cell(label),
    cell(value, alignRight: true),
  ]);
}

/// 🔹 CELL
pw.Widget cell(String text,
    {bool alignRight = false, bool bold = false}) {
  return pw.Padding(
    padding: const pw.EdgeInsets.all(4),
    child: pw.Text(
      text,
      textAlign:
          alignRight ? pw.TextAlign.right : pw.TextAlign.left,
      style: pw.TextStyle(
        fontWeight:
            bold ? pw.FontWeight.bold : pw.FontWeight.normal,
      ),
    ),
  );
}

/// 🔹 TITLE BAR
pw.Widget titleBar(String text) {
  return pw.Container(
    width: double.infinity,
    color: PdfColors.grey300,
    padding: const pw.EdgeInsets.all(5),
    child: pw.Text(text,
        style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
  );
}

/// 🔹 BANK ROW
pw.Widget bankRow(String label, String value) {
  return pw.Row(
    children: [
      pw.Expanded(child: pw.Text(label)),
      pw.Text(" : "),
      pw.Expanded(
        child: pw.Text(value,
            style: pw.TextStyle(color: PdfColors.blue)),
      ),
    ],
  );
}